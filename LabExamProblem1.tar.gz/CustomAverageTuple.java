
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;

public class CustomAverageTuple implements Writable{

	private int value = new Integer(0);
	private Double minCgpa = new Double(0);
	private Double maxCgpa = new Double(0);
	
	public Integer getValue(){
		return value;
	}
	
	public void setValue(Integer value){
		this.value = value;
	}
	
	public Double getminCgpa(){
		return minCgpa;
	}
	
	public void setminCgpa(Double minCgpa){
		this.minCgpa = minCgpa;
	}
	
	public Double getmaxCgpa(){
		return maxCgpa;
	}
	
	public void setmaxCgpa(Double maxCgpa){
		this.maxCgpa = maxCgpa;
	}
	
	@Override
	public void readFields(DataInput in) throws IOException {
		// TODO Auto-generated method stub
		value = in.readInt();
		minCgpa=in.readDouble();
		maxCgpa=in.readDouble();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		// TODO Auto-generated method stub
		out.writeInt(value);
		out.writeDouble(minCgpa);
		out.writeDouble(maxCgpa);
		
	}
	
	public String toString(){
		return minCgpa + "," + maxCgpa;
		
	}

}
