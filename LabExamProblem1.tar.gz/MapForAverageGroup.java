import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapForAverageGroup extends Mapper<LongWritable, Text, Text, CustomAverageTuple> {

	private CustomAverageTuple tuple = new CustomAverageTuple();
  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

    String content = value.toString();
    
    String[] lines = content.split("\n");
    
    for(String line: lines){
    	String[] tokens = line.split(",");
    	tuple.setValue(Integer.parseInt(tokens[3]));
    	tuple.setminCgpa(Double.parseDouble(tokens[5]));
    	tuple.setmaxCgpa(Double.parseDouble(tokens[5]));
    	context.write(new Text(tokens[3]), tuple);
    	
    }

  }
}