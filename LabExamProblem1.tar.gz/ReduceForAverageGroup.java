import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReduceForAverageGroup extends Reducer<Text, CustomAverageTuple, Text, CustomAverageTuple> {

	private CustomAverageTuple result = new CustomAverageTuple();
  @Override
  public void reduce(Text key, Iterable<CustomAverageTuple> values, Context context)
      throws IOException, InterruptedException {


	  double minCgpa=4.00;
	  double maxCgpa=0;
	  
	  for(CustomAverageTuple value: values){
		  if(minCgpa>=value.getminCgpa()){
			  minCgpa=value.getminCgpa();
		  }
		  if(maxCgpa<=value.getmaxCgpa()){
			  maxCgpa=value.getmaxCgpa();
		  }
	  }
	  
	  result.setminCgpa(minCgpa);
	  result.setmaxCgpa(maxCgpa);
	  
	  context.write(key, result);
  }
}
